package common;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import page.CustomerRegistrationPage;

import java.time.Duration;
import java.util.Map;

import static java.lang.Thread.sleep;

public class BasePage {

    // Class chứa các hàm dùng chung cho project
    WebDriver driver;
    WebDriverWait webDriverWait;

    public BasePage() {
        driver = DriverManager.getDriver();
        webDriverWait = new WebDriverWait(driver, Duration.ofSeconds(10), Duration.ofMillis(100));

    }

    /**
     * Mở trang web bằng url
     *
     * @param url: địa chỉ url của trang web cần mở
     */
    protected void goToUrL(String url) {
        driver.get(url);
    }

    /**
     * Chờ cho element visible
     *
     * @param object có thể truyền vào ở định dạng WebElement hoặc By hoặc String xpath
     * @return WebElement
     */
    protected WebElement waitForElementVisible(Object object) {
        if (object instanceof WebElement)
            return webDriverWait.until(ExpectedConditions.visibilityOf((WebElement) object));
        else if (object instanceof String) {
            return webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(String.valueOf(object))));
        } else if (object instanceof By) {
            return webDriverWait.until(ExpectedConditions.visibilityOfElementLocated((By) object));
        } else {
            throw new RuntimeException("Your selector is invalid");
        }
    }

    /**
     * Get string xpath
     *
     * @param format String dạng dynamic
     * @param args   tham số truyền vào string dynamic
     * @return string xpath
     */
    protected String getStringDynamicLocator(String format, Object... args) {
        return String.format(format, args);
    }

    /**
     * Get WebElement
     *
     * @param object có thể truyền vào ở định dạng WebElement hoặc By hoặc String xpath
     * @return WebElement
     */
    protected WebElement getWebElement(Object object) {
        WebElement element;
        if (object instanceof WebElement) element = (WebElement) object;
        else if (object instanceof String) {
            element = driver.findElement(By.xpath(String.valueOf(object)));
        } else if (object instanceof By) {
            element = driver.findElement((By) object);
        } else {
            throw new RuntimeException("Your selector is invalid, you only user String, By or WebElement object");
        }
        return element;
    }

    /**
     * Get text của element
     *
     * @param element có thể truyền vào ở định dạng WebElement hoặc By hoặc String xpath
     * @return text của element
     */
    protected String getTextElement(Object element) {
        return getWebElement(element).getText().trim();
    }

    /**
     * Nhập dữ liệu vào ô tex tbox
     *
     * @param textBoxName  tên trường text box
     * @param textBoxValue giá trị muốn nhập vào text box
     */
    protected void inputDataToTextBox(String textBoxName, String textBoxValue) {
        String textBoxXpath = getStringDynamicLocator(BaseLocator.XPATH_PAGE_TEXT_BOX_BY_TEXT, textBoxName);
        WebElement element = getWebElement(textBoxXpath);
        element.clear();
        element.sendKeys(textBoxValue);

        //Đoạn này thêm vào chỉ với mục đích làm chậm lại tốc độ điền để có thể nhìn thấy chương trình chạy thôi
        sleepForNextStep(100);
    }

    /**
     * Sleep theo số milliseconds chỉ định
     *
     * @param milliseconds số mili giây cần wait
     */
    protected void sleepForNextStep(long milliseconds) {
        try {
            sleep(milliseconds);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Chuyển chuỗi json string sang map
     *
     * @param stringJs chuỗi json
     * @return map
     */
    protected Map<String, Object> convertStringJsonToMap(String stringJs) {
        ObjectMapper mapper = new ObjectMapper();
        // convert JSON string to Map
        try {
            return mapper.readValue(stringJs, new TypeReference<>() {
            });
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Click vào element
     *
     * @param object có thể truyền vào ở định dạng WebElement hoặc By hoặc String xpath
     */
    protected void clickToElement(Object object) {
        if (object == null)
            throw new RuntimeException("Your selector is invalid");
        try {
            WebElement element = waitToClick(object);
            scrollToElement(element);
            element.click();
        } catch (Exception e) {
            System.out.println("Exception" + e);
        }
    }

    /**
     * Wait đến khi element có thể click
     *
     * @param object có thể truyền vào ở định dạng WebElement hoặc By hoặc String xpath
     * @return WebElement
     */
    protected WebElement waitToClick(Object object) {
        if (object instanceof WebElement)
            return webDriverWait.until(ExpectedConditions.elementToBeClickable((WebElement) object));
        else if (object instanceof String) {
            return webDriverWait.until(ExpectedConditions.elementToBeClickable(By.xpath(String.valueOf(object))));
        } else if (object instanceof By) {
            return webDriverWait.until(ExpectedConditions.elementToBeClickable((By) object));
        } else {
            throw new RuntimeException("Your selector is invalid");
        }
    }

    /**
     * Chọn giá trị trong dropdown bằng cách click vào dropdown sau đó select giá trị cần
     *
     * @param controlName Tên của dropdown cần thao tác
     * @param optionVal   giá trị cần chọn
     */
    protected void selectOptionInDropDown(String controlName, String optionVal) {
        WebElement controlElement = getWebElement(getStringDynamicLocator(BaseLocator.XPATH_PAGE_CONTROL_BY_TEXT, controlName));
        clickToElement(controlElement);

        String opt = getStringDynamicLocator(".//option[text()='%s']", optionVal);
        clickToElement(controlElement.findElement(By.xpath(opt)));
        sleepForNextStep(100);
    }

    /**
     * Đi đến trang đăng ký tài khoản
     *
     * @return CustomerRegistrationPage
     */
    public CustomerRegistrationPage gotoRegistrationPage() {
        String url = "https://practicesoftwaretesting.com/#/auth/register";
        goToUrL(url);
        waitForElementVisible(getStringDynamicLocator(BaseLocator.XPATH_PAGE_TITLE_BY_TEXT, "Customer registration"));
        return new CustomerRegistrationPage();
    }

    /**
     * Scroll tới element cần view
     *
     * @param element element cần scroll, có thể truyền vào dạng WebElement hoặc By hoặc String Xpath
     */
    protected void scrollToElement(Object element) {
        getJsExecutor().executeScript("arguments[0].scrollIntoView(true)", getWebElement(element));
    }

    protected JavascriptExecutor getJsExecutor() {
        return (JavascriptExecutor) driver;
    }


}
