package common;

public class BaseLocator {
    public static String XPATH_PAGE_TITLE_BY_TEXT = "//div[@class='container']//h3[contains(text(),'%s')]";
    public static String XPATH_PAGE_TEXT_BOX_BY_TEXT = "//label[contains(text(),'%s')]//following-sibling::input";
    public static String XPATH_PAGE_CONTROL_BY_TEXT = "//label[contains(text(),'%s')]//following-sibling::select";
    public static String XPATH_PAGE_BUTTON_BY_TEXT = "//button[normalize-space(text())='%s']";
    public static String XPATH_ERROR_MESSAGE_FIELD = "//label[contains(text(),'%s')]//parent::div//div[contains(@class,'alert-danger')]//div";

}
