package common;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

import java.time.Duration;

public class TestBase {
    WebDriver webDriver;

    @BeforeClass
    public void beforeClass() {
        //Khởi tạo chrome driver
        WebDriverManager.chromedriver().setup();
        ChromeOptions chromeOptions = new ChromeOptions();
        chromeOptions.addArguments("--start-maximized");
        chromeOptions.addArguments("--remote-allow-origins=*");
        webDriver = new ChromeDriver(chromeOptions);
        DriverManager.setDriver(webDriver);

        //Set implicitWait
        webDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
    }

//    @AfterClass(alwaysRun = true)
//    public void afterClass() {
//        //Đóng driver khi thực thi xong suite
//        webDriver.quit();
//    }
}
