package common;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Hashtable;
import java.util.Objects;

public class ExcelHelper {
    private Sheet sh;

    /**
     * Đọc dữ liệu trong file excel, trả về data dạng Hashtable<String, String> data
     *
     * @param excelPath đường dẫn chưa file excel
     * @param sheetName tên sheet chứa dữ liệu
     * @param tcName    tên testcase
     * @param startRow  index của dòng đầu tiên chứa dữ liệu
     * @return Hashtable<String, String> data
     */
    public Object[][] getDataHashTable(String excelPath, String sheetName, String tcName, int startRow) {
        Object[][] data = null;

        try {
            File f = new File(excelPath);
            if (!f.exists()) {
                try {
                    throw new IOException("File Excel path not found.");
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            FileInputStream fis = new FileInputStream(excelPath);

            Workbook wb = new XSSFWorkbook(fis);

            sh = wb.getSheet(sheetName);

            int endRow = getLastRowNum();
            int columns = getColumns();

            data = new Object[endRow - startRow][1];
            Hashtable<String, String> table;

            // Duyệt từng dòng dữ liệu
            for (int rowNum = startRow; rowNum < endRow; rowNum++) {
                table = new Hashtable<>();

                String tcNameAtCell = getCellData(0, rowNum);
                // Get các dòng dữ liệu map với tên test case -> duệt từng cột dữ liệu
                if (Objects.nonNull(tcNameAtCell) && tcNameAtCell.equalsIgnoreCase(tcName)) {
                    for (int colNum = 0; colNum < columns; colNum++) {
                        // Put dữ liệu <Tên trường, Dữ liệu của trường>
                        table.put(getCellData(colNum, 0), getCellData(colNum, rowNum));
                    }
                    data[rowNum - startRow][0] = table;
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }

        return data;
    }

    /**
     * Lấy data của cell
     *
     * @param columnIndex index của cột
     * @param rowIndex    index của hàng
     * @return dữ liệu của cell
     */
    private String getCellData(int columnIndex, int rowIndex) {
        try {
            Cell cell = sh.getRow(rowIndex).getCell(columnIndex);
            String CellData = null;
            switch (cell.getCellType()) {
                case STRING:
                    CellData = cell.getStringCellValue();
                    break;
                case NUMERIC:
                    if (DateUtil.isCellDateFormatted(cell)) {
                        CellData = String.valueOf(cell.getDateCellValue());
                    } else {
                        CellData = String.valueOf((long) cell.getNumericCellValue());
                    }
                    break;
                case BOOLEAN:
                    CellData = Boolean.toString(cell.getBooleanCellValue());
                    break;
                case BLANK:
                    CellData = "";
                    break;
            }
            return CellData;
        } catch (Exception e) {
            return "";
        }
    }

    /**
     * Lấy index của cột cuối cùng
     *
     * @return số cột
     */
    private int getColumns() {
        try {
            Row row = sh.getRow(0);
            return row.getLastCellNum();
        } catch (Exception e) {
            System.out.println(e.getMessage());
            throw (e);
        }
    }

    /**
     * Lấy index của dòng cuối cùng
     *
     * @return số dòng
     */
    private int getLastRowNum() {
        return sh.getLastRowNum() + 1;
    }


}
