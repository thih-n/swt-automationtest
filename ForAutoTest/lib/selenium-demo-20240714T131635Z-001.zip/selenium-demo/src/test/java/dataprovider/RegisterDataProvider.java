package dataprovider;

import common.ExcelHelper;
import org.testng.annotations.DataProvider;

import java.lang.reflect.Method;

public class RegisterDataProvider {
    @DataProvider(name = "registrationData")
    public Object[][] registrationData(Method method) {
        ExcelHelper excelHelper = new ExcelHelper();
        String projectPath = System.getProperty("user.dir");
        String dataPath = projectPath + "/src/test/resources/datatest/registerData.xlsx";
        Object[][] data = excelHelper.getDataHashTable(dataPath, "Sheet1", method.getName(), 1);
        return data;
    }
}
