package page;

import common.BaseLocator;
import common.BasePage;
import org.testng.Assert;

import java.util.Hashtable;
import java.util.Map;
import java.util.Objects;

public class CustomerRegistrationPage extends BasePage {
    public CustomerRegistrationPage() {
    }

    /**
     * Nhập dữ liệu vào form đăng ký account
     *
     * @param data dữ liệu cần điền
     */
    public void inputCustomerData(Hashtable<String, String> data) {
        // Nhập dữ liệu vào trường First name
        // data.get("First name") lấy ra data của First name trong Hashtable (được đọc dữ liệu từ file excel)
        inputDataToTextBox("First name", data.get("First name"));

        // Nhập dữ liệu vào trường Last name
        inputDataToTextBox("Last name", data.get("Last name"));

        // Nhập dữ liệu vào trường Date of Birth
        inputDataToTextBox("Date of Birth", data.get("Date of Birth"));

        // Nhập dữ liệu vào trường Address
        inputDataToTextBox("Address", data.get("Address"));

        // Nhập dữ liệu vào trường Postcode
        inputDataToTextBox("Postcode", data.get("Postcode"));

        // Nhập dữ liệu vào trường City
        inputDataToTextBox("City", data.get("City"));

        // Nhập dữ liệu vào trường State
        inputDataToTextBox("State", data.get("State"));

        // Chọn giá trị ở trường Country
        selectOptionInDropDown("Country", data.get("Country"));

        // Nhập dữ liệu vào trường Phone
        inputDataToTextBox("Phone", data.get("Phone"));

        // Nhập dữ liệu vào trường Email address
        inputDataToTextBox("Email address", data.get("Email address"));

        // Nhập dữ liệu vào trường Password
        inputDataToTextBox("Password", data.get("Password"));
    }

    /**
     * Click Register button, thực hiện đăng ký account
     */
    public void registerAccount() {
        String registerBtnXpath = getStringDynamicLocator(BaseLocator.XPATH_PAGE_BUTTON_BY_TEXT, "Register");
        clickToElement(registerBtnXpath);
    }

    /**
     * Kiểm tra hiển thị thông báo tại các trường không hợp lệ
     *
     * @param data dữ liệu chứa message mong đợi cần hiển thị
     */
    public void verifyUnsuccessfulRegistration(Hashtable<String, String> data) {
        Map<String, Object> dataMap = convertStringJsonToMap(data.get("Error message"));
        verifyDisplayErrorMsgAtPhone(dataMap);
        verifyDisplayErrorMsgAtEmail(dataMap);
        verifyDisplayErrorMsgAtPassWord(dataMap);
        //todo: implement cho cac field con lai sau
    }

    /**
     * Kiểm tra hiển thị thông báo lỗi tại trường Phone
     *
     * @param dataMap dữ liệu chứa message mong đợi cần hiển thị
     */
    private void verifyDisplayErrorMsgAtPhone(Map<String, Object> dataMap) {
        if (Objects.nonNull(dataMap.get("Phone"))) {
            verifyDisplayErrorMsgAtField("Phone", dataMap.get("Phone").toString());
        }
    }

    /**
     * Kiểm tra hiển thị thông báo lỗi tại trường Email address
     *
     * @param dataMap dữ liệu chứa message mong đợi cần hiển thị
     */
    private void verifyDisplayErrorMsgAtEmail(Map<String, Object> dataMap) {
        if (Objects.nonNull(dataMap.get("Email address"))) {
            verifyDisplayErrorMsgAtField("Email address", dataMap.get("Email address").toString());
        }
    }

    /**
     * Kiểm tra hiển thị thông báo lỗi tại trường Password
     *
     * @param dataMap dữ liệu chứa message mong đợi cần hiển thị
     */
    private void verifyDisplayErrorMsgAtPassWord(Map<String, Object> dataMap) {
        if (Objects.nonNull(dataMap.get("Password"))) {
            verifyDisplayErrorMsgAtField("Password", dataMap.get("Password").toString());
        }
    }

    /**
     * Kiểm tra hiển thị thông báo lỗi tại trường chỉ định
     *
     * @param fieldName   tên trường cần kiểm tra
     * @param expectedMsg thông báo mong đợi sẽ hiển thị
     */
    private void verifyDisplayErrorMsgAtField(String fieldName, String expectedMsg) {
        String actualMsg = getTextElement(getStringDynamicLocator(BaseLocator.XPATH_ERROR_MESSAGE_FIELD, fieldName, expectedMsg));
        Assert.assertEquals(actualMsg, expectedMsg);
    }
}
