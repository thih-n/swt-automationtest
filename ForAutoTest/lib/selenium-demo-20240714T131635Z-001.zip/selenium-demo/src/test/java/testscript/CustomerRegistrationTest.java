package testscript;

import common.BasePage;
import common.TestBase;
import dataprovider.RegisterDataProvider;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import page.CustomerRegistrationPage;

import java.util.Hashtable;

public class CustomerRegistrationTest extends TestBase {
    BasePage basePage;

    @BeforeClass
    public void init() {
        basePage = new BasePage();
    }

    @Test(priority = 1,
            description = "Đăng ký account với tài khoản không hợp lệ",
            dataProvider = "registrationData",
            dataProviderClass = RegisterDataProvider.class)
    public void Register_With_Invalid_Data(Hashtable<String, String> data) {
        CustomerRegistrationPage registrationPage = basePage.gotoRegistrationPage();
        registrationPage.inputCustomerData(data);
        registrationPage.registerAccount();
        registrationPage.verifyUnsuccessfulRegistration(data);
    }
}
